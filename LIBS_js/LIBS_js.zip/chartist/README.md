# Chartist Legacy Repository for Chartist 0.x

This Repository only serves to maintain the Chartist 0.x documentation and for maintenance of dependent packages.

If you're looking for the current and transferred Chartist repository,
please visit https://github.com/chartist-js/chartist
